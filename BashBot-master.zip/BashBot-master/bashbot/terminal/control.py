class TerminalControl:
    def __init__(self, emoji, text):
        self.emoji = emoji
        self.text = text
